package lab3;

public class NodeAn<E extends Comparable<E>> {

    private E value;
    private boolean isRed;
    private NodeAn<E> left;
    private NodeAn<E> right;
    private NodeAn<E> parent;

    public NodeAn(E value, boolean isRed) {
        this.value = value;
        this.isRed = isRed;
        if (isRed) {
            left = new NodeAn<>(null, false);
            right = new NodeAn<>(null, false);
            left.setParent(this);
            right.setParent(this);
        }
    }

    public E getValue() {
        return value;
    }

    public void setValue(E value) {
        this.value = value;
    }
    
    public void changeColor() {
        isRed = !isRed;
    }

    public void setRed() {
        isRed = true;
    }

    public void setBlack() {
        isRed = false;
    }

    public boolean isNodeRed() {
        return isRed;
    }

    public NodeAn<E> getLeft() {
        return left;
    }

    public void setLeft(NodeAn<E> left) {
        this.left = left;
    }

    public NodeAn<E> getRight() {
        return right;
    }

    public void setRight(NodeAn<E> right) {
        this.right = right;
    }

    public NodeAn<E> getParent() {
        return parent;
    }

    public void setParent(NodeAn<E> parent) {
        this.parent = parent;
    }

    public NodeAn<E> getUncle() {
        NodeAn<E> gp = getGrandparent();
        if (gp == null) {
            return null;
        }
        if (parent == gp.getRight()) {
            return gp.getLeft();
        }
        return gp.getRight();
    }

    public NodeAn<E> getGrandparent() {
        return parent.getParent();
    }

}
