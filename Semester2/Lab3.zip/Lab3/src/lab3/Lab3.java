package lab3;

public class Lab3 {

    public static void main(String[] args) {
        
        RedBlackTree tree = new RedBlackTree(3);
        
    }
    
}
