package lab3;

public class RedBlackTree<E extends Comparable<E>> {

    private Node<E> root;

    public RedBlackTree(E data) {
        this.root.setData(data);
    }

    public void insert(E data) {
        root = insert(root, data);
    }

    private Node<E> insert(Node<E> node, E data) {
        if (node == null) {
            return new Node<E>(data, false);
        }
        if (node.getData().compareTo(data) > 0) {
            return node.setLeft(node.getLeft());
        }
        return node;
    }

}
