package lab3;

public class RedBlackTreeAN<E extends Comparable<E>> {

    private NodeAn<E> root;

    public RedBlackTreeAN(E value) {
        root = new NodeAn<>(value, true);
        root.changeColor();
    }

    public void add(E value) {
        NodeAn<E> added = new NodeAn<>(value, true);
        addToTree(added);
        case1(added);
    }

    public void addToTree(NodeAn<E> added) {
        E value = added.getValue();
        NodeAn<E> current = this.root;
        while (true) {
            Comparable<E> currentValue = current.getValue();
            if (currentValue.compareTo(value) > 0) {
                if (current.getLeft().getValue() == null) {
                    added.setParent(current);
                    current.setLeft(added);
                    return;
                }
                current = current.getLeft();
            } else if (currentValue.compareTo(value) < 0) {
                if (current.getRight().getValue() == null) {
                    added.setParent(current);
                    current.setRight(added);
                    return;
                }
                current = current.getRight();
            } else {
                current.setValue(value);
                return;
            }
        }
    }

    private void case1(NodeAn<E> node) {
        if (node.getParent() == null) {
            node.setBlack();
            return;
        }
        case2(node);
    }

    private void case2(NodeAn<E> node) {
        if (!node.getParent().isNodeRed()) {
            return;
        }
        case3(node);
    }

    private void case3(NodeAn<E> node) {
        if (node.getParent() == null) {
            case2(node);
        }
        NodeAn<E> gp = node.getGrandparent();
        NodeAn<E> p = node.getParent();
        NodeAn<E> u = node.getUncle();
        if (u.isNodeRed()) {
            p.changeColor();
            u.changeColor();
            gp.changeColor();
            case1(gp);
        }
        case4(node);
    }

    private void case4(NodeAn<E> node) {
        NodeAn<E> gp = node.getGrandparent();
        NodeAn<E> p = node.getParent();
        NodeAn<E> u = node.getUncle();
        if (p == gp.getLeft() && node == p.getRight()) {
            rotateParentToLeft(node, p, u, gp);
            case5(node.getLeft());
            return;
        }
        if (p == gp.getParent() && node == p.getLeft()) {
            rotateParentToRight(node, p, u, gp);
            case5(node.getRight());
            return;
        }
        case5(node);
    }

    private void case5(NodeAn<E> node) {
        NodeAn<E> gp = node.getGrandparent();
        NodeAn<E> p = node.getParent();
        NodeAn<E> u = node.getUncle();
        p.setBlack();
        gp.changeColor();
        if (p == gp.getLeft() && node == p.getLeft()) {
            rotateGrandparentToRight(node, p, u, gp);
        }
        if (p == gp.getLeft() && node == p.getRight()) {
            rotateGrandparentToLeft(node, p, u, gp);
        }
    }

    private void rotateParentToLeft(NodeAn<E> node, NodeAn<E> p, NodeAn<E> u, NodeAn<E> gp) {
        if (p == null) {
            return;
        }
        NodeAn<E> nodeLeft = node.getLeft();
        node.setParent(gp);
        gp.setLeft(node);
        node.setLeft(p);
        p.setParent(node);
        p.setRight(nodeLeft);
    }

    private void rotateParentToRight(NodeAn<E> node, NodeAn<E> p, NodeAn<E> u, NodeAn<E> gp) {
        if (p == null) {
            return;
        }
        NodeAn<E> nodeRight = node.getRight();
        node.setParent(gp);
        gp.setRight(node);
        node.setRight(p);
        p.setParent(node);
        p.setLeft(nodeRight);
    }

    private void rotateGrandparentToLeft(NodeAn<E> node, NodeAn<E> p, NodeAn<E> u, NodeAn<E> gp) {
        NodeAn<E> pRight = p.getRight();
        NodeAn<E> ggp = gp.getParent();
        p.setParent(ggp);
        if (ggp != null) {
            if (ggp.getLeft() == gp) {
                ggp.setLeft(p);
            } else {
                ggp.setRight(p);
            }
        } else {
            root = p;
        } 
        gp.setLeft(pRight);
        pRight.setParent(gp);
        gp.setParent(p);
        p.setRight(gp);
    }

    private void rotateGrandparentToRight(NodeAn<E> node, NodeAn<E> p, NodeAn<E> u, NodeAn<E> gp) {
        NodeAn<E> pLeft = p.getLeft();
        NodeAn<E> ggp = gp.getParent();
        p.setParent(ggp);
        if (ggp != null) {
            if (ggp.getLeft() == gp) {
                ggp.setRight(p);
            } else {
                ggp.setLeft(p);
            }
        } else {
            root = p;
        } 
        gp.setRight(pLeft);
        pLeft.setParent(gp);
        gp.setParent(p);
        p.setLeft(gp);
    }

}
