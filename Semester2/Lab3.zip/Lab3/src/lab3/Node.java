package lab3;

class Node<E extends Comparable<E>> {

    private E data;
    private Node<E> left;
    private Node<E> right;
    private boolean isRed;
    private Node<E> parent;

    public Node(E data) {
        this.data = data;
        this.isRed = isRed;
        left = null;
        right = null;
    }

    public Node(E data, boolean isRed) {
        this.data = data;
        this.isRed = isRed;
        if (isRed) {
            left = (new Node<E>(null));
            left.setParent(this);
            right = (new Node<E>(null));
            right.setParent(this);
        } else {
            left = null;
            right = null;
        }
    }

    public void red(Node<E> node) {

    }

    public void setData(E data) {
        this.data = data;
    }

    public void setLeft(Node<E> left) {
        this.left = left;
    }

    public void setRight(Node<E> right) {
        this.right = right;
    }

    public void setParent(Node<E> parent) {
        this.parent = parent;
    }

    public E getData() {
        return data;
    }

    public Node<E> getLeft() {
        return left;
    }

    public Node<E> getRight() {
        return right;
    }

    public boolean isRed() {
        return isRed;
    }

    public Node<E> getParent() {
        return parent;
    }

}
